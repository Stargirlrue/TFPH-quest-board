# How to upload this to GitHub (no typing needed)

This zip has 7 files that replace the broken/old ones in your repo.

## Step 1: Unzip it
On your phone, tap the downloaded zip, your Files app should offer
"Extract" or "Unzip", do that. You'll get a folder called `tfph-update`
with everything inside, in the right sub-folders already.

## Step 2: Go to your GitHub repo in Chrome
Open github.com/Stargirlrue/TFPH-quest-board

## Step 3: Upload files
1. Tap **Add file** → **Upload files**
2. Tap to browse, then try to select the **entire `tfph-update` folder**
   at once (some phones show an "Upload folder" option here, if yours
   does, use it, it keeps everything in the right place automatically)
3. If it only lets you pick individual files (no folder option), upload
   them one at a time instead, GitHub will ask to confirm the path for
   each, you can just confirm it since the file names already contain
   the full path, like `app/api/teams/route.js`
4. Scroll down, tap **Commit changes**

That's it, one upload (or a few taps if doing it file by file) instead
of retyping anything. GitHub will automatically overwrite the old
versions of these same files since they share the same names and paths.

After committing, Vercel rebuilds automatically, give it 1-2 minutes,
then test the site again.
