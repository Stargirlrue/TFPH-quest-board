# One file to update

Just `app/tasks/page.js`, replaces the link button with the compact
pill + icon style you picked, and swaps "0 FPP" for a "Required" badge
on tasks worth zero points.

Built and tested, no errors.

## Upload
1. Unzip this
2. github.com/Stargirlrue/TFPH-quest-board → Add file → Upload files
3. Select the `app/tasks/page.js` file from the unzipped folder
   (GitHub will know to replace the existing one at that same path)
4. Commit changes
5. Give Vercel ~1-2 minutes, then check the Tasks page
