"use client";
import { useEffect, useState } from "react";

const DONE_MESSAGES = [
  "Good job champ 🏆 more tasks in a while, crocodile",
  "You ate that 🍽️ new tasks loading soon",
  "Certified task destroyer 💅 check back later",
  "That's a wrap for now 🎬 more drops incoming",
];

function LinkIcon() {
  return (
    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6" />
      <polyline points="15 3 21 3 21 9" />
      <line x1="10" y1="14" x2="21" y2="3" />
    </svg>
  );
}

export default function Tasks() {
  const [user, setUser] = useState(null);
  const [tasks, setTasks] = useState([]);
  const [mySubs, setMySubs] = useState([]);
  const [status, setStatus] = useState({});
  const [doneMsg] = useState(DONE_MESSAGES[Math.floor(Math.random() * DONE_MESSAGES.length)]);

  useEffect(() => {
    const saved = localStorage.getItem("tfph_user");
    if (saved) setUser(JSON.parse(saved));
    fetch("/api/tasks").then((r) => r.json()).then((d) => setTasks(d.tasks || []));
  }, []);

  useEffect(() => {
    if (!user) return;
    fetch(`/api/mysubmissions?userId=${user.id}`).then((r) => r.json()).then((d) => setMySubs(d.submissions || []));
  }, [user]);

  function fileToBase64(file) {
    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result);
      reader.readAsDataURL(file);
    });
  }

  async function handleSubmit(taskId, file) {
    if (!user || !file) return;
    setStatus((s) => ({ ...s, [taskId]: "loading" }));
    const base64 = await fileToBase64(file);
    const res = await fetch("/api/submit", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        userId: user.id,
        questId: taskId,
        proofImageBase64: base64,
        proofFileName: file.name,
        proofType: file.type,
      }),
    });
    const data = await res.json();
    if (res.ok) {
      setMySubs((s) => [{ quest_id: taskId, status: "pending" }, ...s]);
    } else {
      setStatus((s) => ({ ...s, [taskId]: data.error || "Hmm that didn't work, try again bestie" }));
    }
  }

  if (!user) {
    return (
      <main className="max-w-md mx-auto px-4 py-16 text-center">
        <p className="text-white/70">
          Hold up, <a href="/" className="text-neon-blue underline">sign in on the home page</a> first.
        </p>
      </main>
    );
  }

  function subFor(taskId) {
    return mySubs.find((s) => s.quest_id === taskId && (s.status === "pending" || s.status === "approved"));
  }

  const remaining = tasks.filter((t) => !subFor(t.id));

  return (
    <main className="max-w-xl mx-auto px-4 py-10 space-y-4">
      <h1 className="text-2xl font-bold">Tasks</h1>

      {tasks.length === 0 && (
        <p className="text-white/40 text-center py-10">It's giving... nothing rn 👀 new tasks dropping soon</p>
      )}

      {tasks.length > 0 && remaining.length === 0 && (
        <p className="text-white/70 text-center py-10 text-lg font-medium">{doneMsg}</p>
      )}

      {tasks.map((t) => {
        const sub = subFor(t.id);
        const rejected = mySubs.find((s) => s.quest_id === t.id && s.status === "rejected");
        return (
          <div key={t.id} className="bg-surface border border-white/10 rounded-2xl p-5">
            <div className="flex justify-between items-center gap-2">
              <h3 className="font-semibold">{t.title}</h3>
              {t.fpp_value > 0 ? (
                <span className="text-xs font-bold text-neon-blue bg-neon-blue/10 px-2 py-1 rounded-full flex-shrink-0">{t.fpp_value} FPP</span>
              ) : (
                <span className="text-xs font-bold text-neon-pink bg-neon-pink/10 px-2 py-1 rounded-full flex-shrink-0">Required</span>
              )}
            </div>
            {t.description && <p className="text-sm text-white/50 mt-1">{t.description}</p>}
            {t.link_url && (
              <a
                href={t.link_url}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-neon-blue bg-neon-blue/10 px-3 py-1.5 rounded-full mt-2"
              >
                <LinkIcon />
                Visit link
              </a>
            )}

            {sub?.status === "approved" ? (
              <p className="text-neon-blue text-sm mt-3 font-semibold">Cashed out ✅ +{t.fpp_value} FPP secured</p>
            ) : sub?.status === "pending" ? (
              <p className="text-neon-purple text-sm mt-3 font-semibold">Sent 📨 under review, we see you 👀</p>
            ) : (
              <div className="mt-3 space-y-2">
                {rejected && <p className="text-neon-pink text-xs">Didn't quite land last time 😬 give it another shot</p>}
                <input type="file" accept="image/*" className="text-sm text-white/70" onChange={(e) => handleSubmit(t.id, e.target.files[0])} />
                {status[t.id] && status[t.id] !== "loading" && <p className="text-neon-pink text-xs">{status[t.id]}</p>}
                {status[t.id] === "loading" && <p className="text-xs text-white/40">Uploading...</p>}
              </div>
            )}
          </div>
        );
      })}
    </main>
  );
}
