/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./app/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0b0a14",
        surface: "#14121f",
        neon: {
          blue: "#00E5FF",
          pink: "#FF2E9F",
          purple: "#A742FF",
          silver: "#D7DEE8",
        },
      },
    },
  },
  plugins: [],
};
