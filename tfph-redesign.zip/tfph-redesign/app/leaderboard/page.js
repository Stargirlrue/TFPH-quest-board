"use client";
import { useEffect, useState } from "react";

export default function Leaderboard() {
  const [list, setList] = useState([]);

  useEffect(() => {
    fetch("/api/leaderboard").then((r) => r.json()).then((d) => setList(d.leaderboard || []));
  }, []);

  return (
    <main className="max-w-md mx-auto px-4 py-10">
      <h1 className="text-2xl font-extrabold text-center mb-6 bg-gradient-to-r from-neon-blue via-neon-purple to-neon-pink bg-clip-text text-transparent">
        Leaderboard
      </h1>
      <ol className="space-y-2">
        {list.map((u, i) => (
          <li key={u.id} className="bg-surface border border-white/10 rounded-xl px-4 py-3 flex justify-between items-center">
            <span className="flex items-center gap-3">
              <span className="text-white/30 w-6 font-bold">{i + 1}</span>
              <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: u.teams?.color || "#888" }}></span>
              {u.name}
            </span>
            <span className="font-bold text-neon-blue">{u.fpp} FPP</span>
          </li>
        ))}
        {list.length === 0 && (
          <p className="text-center text-white/40 py-10">Nobody's topped the board yet, be the first legend 🏆</p>
        )}
      </ol>
    </main>
  );
}
