export const dynamic = "force-dynamic";

import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase";

export async function GET(request) {
  const userId = new URL(request.url).searchParams.get("userId");
  if (!userId) return NextResponse.json({ error: "Missing userId." }, { status: 400 });

  const db = supabaseAdmin();
  const { data, error } = await db
    .from("submissions")
    .select("id, status, submitted_at, reviewed_at, quest_id, quests(title, fpp_value)")
    .eq("user_id", userId)
    .order("submitted_at", { ascending: false });

  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json({ submissions: data });
}
