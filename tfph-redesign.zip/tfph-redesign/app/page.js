"use client";
import { useEffect, useState } from "react";

const KEY = "tfph_user";

function timeAgo(dateStr) {
  const d = new Date(dateStr);
  return d.toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

export default function Home() {
  const [user, setUser] = useState(null);
  const [teams, setTeams] = useState([]);
  const [name, setName] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [teamId, setTeamId] = useState("");
  const [error, setError] = useState("");
  const [fpp, setFpp] = useState(0);
  const [history, setHistory] = useState([]);

  useEffect(() => {
    const saved = localStorage.getItem(KEY);
    if (saved) setUser(JSON.parse(saved));
    fetch("/api/teams").then((r) => r.json()).then((d) => setTeams(d.teams || []));
  }, []);

  useEffect(() => {
    if (!user) return;
    fetch("/api/leaderboard").then((r) => r.json()).then((d) => {
      const me = (d.leaderboard || []).find((u) => u.id === user.id);
      if (me) setFpp(me.fpp);
    });
    fetch(`/api/mysubmissions?userId=${user.id}`).then((r) => r.json()).then((d) => {
      setHistory((d.submissions || []).filter((s) => s.status === "approved"));
    });
  }, [user]);

  async function handleSignup(e) {
    e.preventDefault();
    setError("");
    if (!name.trim() || !whatsapp.trim() || !teamId) {
      setError("Name, WhatsApp, and your squad's colors, don't skip a step 🎨");
      return;
    }
    const res = await fetch("/api/signup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, whatsapp, teamId }),
    });
    const data = await res.json();
    if (!res.ok) return setError(data.error || "That didn't work, try again bestie");
    setUser(data.user);
    localStorage.setItem(KEY, JSON.stringify(data.user));
  }

  if (!user) {
    return (
      <main className="max-w-sm mx-auto px-4 py-16">
        <h1 className="text-3xl font-extrabold text-center mb-1 bg-gradient-to-r from-neon-blue via-neon-purple to-neon-pink bg-clip-text text-transparent">
          Welcome to TFPH
        </h1>
        <p className="text-center text-white/50 mb-6">Pick your squad, start stacking FPP</p>
        <form onSubmit={handleSignup} className="bg-surface border border-white/10 rounded-2xl p-6 space-y-4">
          <input className="w-full bg-black/30 border border-white/10 rounded-xl px-3 py-2 placeholder-white/30" placeholder="Your name" value={name} onChange={(e) => setName(e.target.value)} />
          <input className="w-full bg-black/30 border border-white/10 rounded-xl px-3 py-2 placeholder-white/30" placeholder="WhatsApp number" value={whatsapp} onChange={(e) => setWhatsapp(e.target.value)} />

          <div>
            <p className="text-xs font-semibold text-white/50 mb-2">Who recruited you? Pick their squad</p>
            <div className="grid grid-cols-2 gap-2">
              {teams.map((t) => (
                <button
                  type="button"
                  key={t.id}
                  onClick={() => setTeamId(t.id)}
                  className="rounded-xl px-3 py-2 text-sm font-semibold border-2 flex items-center gap-2 transition"
                  style={{
                    background: teamId === t.id ? t.color : `${t.color}22`,
                    borderColor: t.color,
                    color: teamId === t.id ? "#0b0a14" : "#fff",
                  }}
                >
                  <span className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: t.color }}></span>
                  {t.name}
                </button>
              ))}
            </div>
          </div>

          {error && <p className="text-neon-pink text-sm">{error}</p>}
          <button className="w-full bg-gradient-to-r from-neon-blue to-neon-purple text-ink rounded-xl py-2.5 font-bold">
            Let's go
          </button>
        </form>
      </main>
    );
  }

  const myTeam = teams.find((t) => t.id === user.team_id);

  return (
    <main className="max-w-md mx-auto px-4 py-12">
      <div className="text-center">
        <h1 className="text-2xl font-bold">Hey, {user.name} 👋</h1>
        {myTeam && (
          <span
            className="inline-flex items-center gap-2 mt-2 px-3 py-1 rounded-full text-xs font-semibold"
            style={{ background: `${myTeam.color}22`, color: myTeam.color, border: `1px solid ${myTeam.color}` }}
          >
            <span className="w-2 h-2 rounded-full" style={{ background: myTeam.color }}></span>
            {myTeam.name}
          </span>
        )}
      </div>

      <div className="bg-gradient-to-br from-surface to-black/40 border border-white/10 rounded-2xl p-8 mt-6 text-center">
        <p className="text-xs text-white/50 uppercase tracking-widest">Fadeproof Points</p>
        <p className="text-5xl font-extrabold mt-2 bg-gradient-to-r from-neon-blue via-neon-purple to-neon-pink bg-clip-text text-transparent">
          {fpp}
        </p>
      </div>

      <div className="flex gap-3 mt-6 justify-center text-sm">
        <a href="/tasks" className="bg-gradient-to-r from-neon-pink to-neon-purple text-ink rounded-xl px-4 py-2 font-bold">Tasks</a>
        <a href="/leaderboard" className="border border-white/20 rounded-xl px-4 py-2 font-semibold">Leaderboard</a>
      </div>

      <div className="mt-8">
        <p className="text-xs font-semibold text-white/50 uppercase tracking-widest mb-3">Recent activity</p>
        <div className="space-y-2">
          {history.length === 0 && (
            <p className="text-white/40 text-sm text-center py-6">No moves yet, go bag some FPP 💸</p>
          )}
          {history.map((h) => (
            <div key={h.id} className="flex items-center justify-between bg-surface border border-white/10 rounded-xl px-4 py-3">
              <div>
                <p className="text-sm font-medium">{h.quests?.title}</p>
                <p className="text-xs text-white/40">{timeAgo(h.reviewed_at || h.submitted_at)}</p>
              </div>
              <span className="text-neon-blue font-bold text-sm">+{h.quests?.fpp_value} FPP</span>
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
