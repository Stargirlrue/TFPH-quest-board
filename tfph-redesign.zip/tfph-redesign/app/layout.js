import "./globals.css";

export const metadata = {
  title: "The Fadeproof House — Fadeproof Points",
  description: "Complete tasks, earn FPPs, climb the leaderboard.",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="text-white min-h-screen">
        <nav className="flex justify-center gap-6 py-4 border-b border-white/10 bg-black/20 backdrop-blur text-sm font-semibold">
          <a href="/" className="hover:text-neon-blue transition">Home</a>
          <a href="/tasks" className="hover:text-neon-pink transition">Tasks</a>
          <a href="/leaderboard" className="hover:text-neon-purple transition">Leaderboard</a>
        </nav>
        {children}
      </body>
    </html>
  );
}
